<?php
session_start();
include 'db.php';

if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $pass = $_POST['password'];

    // Student Login
    $student = mysqli_query($con, "SELECT * FROM students WHERE email='$email' AND password='$pass'");
    if (mysqli_num_rows($student) == 1) {
        $row = mysqli_fetch_assoc($student);
        $_SESSION['student_id'] = $row['id'];
        $_SESSION['student_name'] = $row['name'];
        header("Location: user/dashboard.php");
        exit();
    }

    // Admin Login
    $admin = mysqli_query($con, "SELECT * FROM admins WHERE username='$email' AND password='$pass'");
    if (mysqli_num_rows($admin) == 1) {
        $_SESSION['admin'] = $email;
        header("Location: admin/dashboard.php");
        exit();
    }

    $error = "Invalid Login Credentials";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
<h3>Login</h3>

<?php if(isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>

<form method="post">
    <input type="text" name="email" class="form-control" placeholder="Email / Admin Username" required><br>
    <input type="password" name="password" class="form-control" placeholder="Password" required><br>
    <button name="login" class="btn btn-success">Login</button>
</form>
</div>
</body>
</html>

