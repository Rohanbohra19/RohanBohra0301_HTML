<!DOCTYPE html>
<html>
<head>
    <title>Complaint Portal</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="css/style.css" rel="stylesheet">
    <style>
        .bg-custom{
            background-color: #010F67;
        }
        .text {
            color: #FDF870;
        }
        .jumbotron .row {
            align-items: center;
        }
        .jumbotron{
             clip-path: polygon(0 0, 100% 0, 100% 88%, 100% 100%, 83% 97%, 16% 97%, 0 100%, 0 90%);
        }
        
    </style>
</head>
<body class="bg-light">



        <nav class="navbar navbar-expand-lg  bg-custom">
          <a class="navbar-brand text" href="#">Oxford</a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarText">
            <ul class="navbar-nav mr-auto">
              <li class="nav-item active">
                <a class="nav-link text" href="#">Home <span class="sr-only">(current)</span></a>
              </li>
              <li class="nav-item ">
                <a class="nav-link text" href="#">About Us</a>
              </li>
              <li class="nav-item ">
                <a class="nav-link text" href="#">Contact</a>
              </li>
            </ul>
            <span class="navbar-text">
              <a href="register.php" class="btn btn-primary">Student Registration</a>
                <a href="login.php" class="btn btn-success">Login</a>
            </span>
          </div>
        </nav>

        <!----hero section----->


          <div class="jumbotron bg-custom text ">
            <div class="row">
                <div class="col-md-6">
                    <h3 >Student Complaint Management System</h3>
                </div>
                <div class="col-md-6" >
                    <img src="images1\oxford-removebg-preview.png" class="img-fluid">
                </div>
            </div>
          </div>   
    <!---hero section end --->

    <div class="container p-3 mt-5 " >

    <div class="row">
        <div class="col-md-4">
            <img src="images1\oxford.jpg" class="img-fluid">
        </div>
        <div class="col-md-8">
            <h2>About US</h2>
            <p>The Oxford Student Complaint Portal is a dedicated platform designed to provide students with a safe, transparent, and efficient way to raise concerns and submit complaints. Our goal is to ensure that every student’s voice is heard and addressed with fairness, confidentiality, and respect. The portal streamlines the complaint process by enabling students to report issues, track their status, and receive timely responses, helping the institution maintain high academic and administrative standards. By promoting accountability and open communication, the Oxford Student Complaint Portal works towards creating a supportive, inclusive, and student-focused academic environment.</p>

        </div>
    </div>

        <div class="container bg-secondary text-light">
            <div class="row">
                <div class="col-md-4">
                  <h3>Contact us</h3>
                            <p>Oxford Institute of Higher Studies</p>
                  <p>Student Support Office, Block A</p>
                  <p>Oxford Campus, MG Road</p>
                  <p>New Delhi – 110001, India</p>
                            
                </div>
                <div class="col-md-4">
                    <h3>E-mail</h3>
                   <a href="#" class="text-light"> <p>support@oxfordcomplaints.edu</p></a>
                    <a href="#" class="text-light"><P>http://www.oxfordcomplaints.edu</P></a>

                    
                </div>
                <div class="col-md-4">
                    <h3>Other Informaton</h3>
                    <p>Phone:</p>
                      <p>+91 98765 43210</p>
                      <p>  +91 11 4567 8900</p>
                    <p>website:</p>
                    <a href="#" class="text-light"><P>http://www.oxfordcomplaints.edu</P></a>
                   

                </div>
                
            </div>
        </div>

            
        </div>


    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>
