<?php
session_start();
include '../db.php';

if (!isset($_SESSION['admin'])) {
    header("Location: ../login.php");
}

$filter = "";
if (isset($_GET['category']) && $_GET['category'] != "") {
    $cat = $_GET['category'];
    $filter = "WHERE category='$cat'";
}

$result = mysqli_query($con, "SELECT * FROM complaints $filter ORDER BY date DESC");
?>

<!DOCTYPE html>
<html>
<head>
<title>All Complaints</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body class="bg-light">

<nav class="navbar navbar-dark bg-dark">
    <span class="navbar-brand">Complaint Management</span>
</nav>

<div class="container mt-4">

<form class="form-inline mb-3">
<select name="category" class="form-control mr-2">
    <option value="">All Categories</option>
    <option>Academic</option>
    <option>Infrastructure</option>
    <option>Library</option>
    <option>Hostel</option>
</select>
<button class="btn btn-info">Filter</button>
</form>

<div class="card shadow">
<div class="card-body">

<table class="table table-striped table-bordered">
<tr>
    <th>ID</th>
    <th>Category</th>
    <th>Complaint</th>
    <th>Status</th>
    <th>Action</th>
</tr>

<?php while($row = mysqli_fetch_assoc($result)) { ?>
<tr>
<td><?php echo $row['id']; ?></td>
<td><?php echo $row['category']; ?></td>
<td><?php echo $row['complaint']; ?></td>
<td><span class="badge badge-secondary"><?php echo $row['status']; ?></span></td>
<td>
<a href="update_status.php?id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Update</a>
</td>
</tr>
<?php } ?>

</table>

</div>
</div>

</div>
</body>
</html>
