<?php
session_start();
include '../db.php';

if (!isset($_SESSION['admin'])) {
    header("Location: ../login.php");
}

$id = $_GET['id'];

if (isset($_POST['update'])) {
    $status = $_POST['status'];
    $response = $_POST['response'];

    mysqli_query($con, "UPDATE complaints SET status='$status', response='$response' WHERE id='$id'");
    header("Location: view_complaints.php");
}

$data = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM complaints WHERE id='$id'"));
?>

<!DOCTYPE html>
<html>
<head>
<title>Update Complaint</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body class="bg-light">

<div class="container mt-5">
<div class="row justify-content-center">
<div class="col-md-6">

<div class="card shadow">
<div class="card-body">

<h4 class="mb-3">Update Complaint</h4>

<form method="post">
<div class="form-group">
<select name="status" class="form-control">
    <option <?php if($data['status']=="Pending") echo "selected"; ?>>Pending</option>
    <option <?php if($data['status']=="In Progress") echo "selected"; ?>>In Progress</option>
    <option <?php if($data['status']=="Resolved") echo "selected"; ?>>Resolved</option>
</select>
</div>

<div class="form-group">
<textarea name="response" class="form-control" rows="4" placeholder="Admin Response"><?php echo $data['response']; ?></textarea>
</div>

<button name="update" class="btn btn-success btn-block">Update</button>
<a href="view_complaints.php" class="btn btn-secondary btn-block">Back</a>
</form>

</div>
</div>

</div>
</div>
</div>

</body>
</html>
