<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: ../login.php");
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Admin Dashboard</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body class="bg-light">

<nav class="navbar navbar-dark bg-dark">
    <span class="navbar-brand">Admin Panel</span>
    <a href="../logout.php" class="btn btn-danger btn-sm">Logout</a>
</nav>

<div class="container mt-5">
<div class="row justify-content-center">

<div class="col-md-6">
<div class="card shadow text-center">
<div class="card-body">
    <h4>Manage Complaints</h4>
    <p class="text-muted">View, filter & respond to complaints</p>
    <a href="view_complaints.php" class="btn btn-primary btn-block">View Complaints</a>
</div>
</div>
</div>

</div>
</div>

</body>
</html>
