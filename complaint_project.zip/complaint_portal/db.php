<?php
$con = mysqli_connect("localhost:3307", "root", "", "complaint_db");

if (!$con) {
    die("Database connection failed");
}
?>
