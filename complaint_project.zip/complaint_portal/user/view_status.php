<?php
session_start();
include '../db.php';

if (!isset($_SESSION['student_id'])) {
    header("Location: ../login.php");
}

$sid = $_SESSION['student_id'];
$result = mysqli_query($con, "SELECT * FROM complaints WHERE student_id='$sid' ORDER BY date DESC");
?>

<!DOCTYPE html>
<html>
<head>
<title>Complaint Status</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body class="bg-light">

<nav class="navbar navbar-dark bg-primary">
    <span class="navbar-brand">Complaint Status</span>
</nav>

<div class="container mt-5">
<div class="card shadow">
<div class="card-body">

<table class="table table-bordered table-hover">
<tr class="bg-light">
    <th>Category</th>
    <th>Complaint</th>
    <th>Status</th>
    <th>Response</th>
    <th>Date</th>
</tr>

<?php while($row = mysqli_fetch_assoc($result)) { 
$statusColor = "secondary";
if($row['status']=="Pending") $statusColor="warning";
if($row['status']=="In Progress") $statusColor="info";
if($row['status']=="Resolved") $statusColor="success";
?>
<tr>
<td><?php echo $row['category']; ?></td>
<td><?php echo $row['complaint']; ?></td>
<td><span class="badge badge-<?php echo $statusColor; ?>"><?php echo $row['status']; ?></span></td>
<td><?php echo $row['response']; ?></td>
<td><?php echo $row['date']; ?></td>
</tr>
<?php } ?>

</table>

<a href="dashboard.php" class="btn btn-secondary">Back</a>

</div>
</div>
</div>

</body>
</html>
