<?php
session_start();
if (!isset($_SESSION['student_id'])) {
    header("Location: ../login.php");
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Student Dashboard</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<style>
    .bg-custom1{
        background-color: #EEE4FB;
    }
    .bg-custom2{
        background-color: #7807FC;
    }
</style>
</head>
<body class="bg-custom1">

<nav class="navbar navbar-dark bg-custom2">
    <span class="navbar-brand">Student Panel</span>
    <span class="text-white">Welcome, <?php echo $_SESSION['student_name']; ?></span>
</nav>

<div class="container mt-5">
<div class="row">

<div class="col-md-4">
    <div class="card shadow">
        <div class="card-body text-center">
            <h5>Submit Complaint</h5>
            <p class="text-muted">Register a new issue</p>
            <a href="submit_complaint.php" class="btn btn-primary btn-block">Submit</a>
        </div>
    </div>
</div>

<div class="col-md-4">
    <div class="card shadow">
        <div class="card-body text-center">
            <h5>Track Status</h5>
            <p class="text-muted">View complaint updates</p>
            <a href="view_status.php" class="btn btn-info btn-block">View</a>
        </div>
    </div>
</div>

<div class="col-md-4">
    <div class="card shadow">
        <div class="card-body text-center">
            <h5>Logout</h5>
            <p class="text-muted">Exit account</p>
            <a href="../logout.php" class="btn btn-danger btn-block">Logout</a>
        </div>
    </div>
</div>

</div>
</div>

</body>
</html>
