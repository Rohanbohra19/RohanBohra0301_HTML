<?php
session_start();
include '../db.php';

if (!isset($_SESSION['student_id'])) {
    header("Location: ../login.php");
}

if (isset($_POST['submit'])) {
    $sid = $_SESSION['student_id'];
    $cat = $_POST['category'];
    $comp = $_POST['complaint'];

    mysqli_query($con, "INSERT INTO complaints (student_id, category, complaint) VALUES ('$sid','$cat','$comp')");
    $msg = "Complaint submitted successfully!";
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Submit Complaint</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body class="bg-light">

<nav class="navbar navbar-dark bg-primary">
    <span class="navbar-brand">Submit Complaint</span>
</nav>

<div class="container mt-5">
<div class="row justify-content-center">
<div class="col-md-6">

<div class="card shadow">
<div class="card-body">

<?php if(isset($msg)) echo "<div class='alert alert-success'>$msg</div>"; ?>

<form method="post">
    <div class="form-group">
        <label>Complaint Category</label>
        <select name="category" class="form-control" required>
            <option value="">Select Category</option>
            <option>Academic</option>
            <option>Infrastructure</option>
            <option>Library</option>
            <option>Hostel</option>
            <option>Other</option>
        </select>
    </div>

    <div class="form-group">
        <label>Complaint Description</label>
        <textarea name="complaint" class="form-control" rows="4" required></textarea>
    </div>

    <button name="submit" class="btn btn-primary btn-block">Submit Complaint</button>
    <a href="dashboard.php" class="btn btn-secondary btn-block">Back</a>
</form>

</div>
</div>

</div>
</div>
</div>

</body>
</html>
