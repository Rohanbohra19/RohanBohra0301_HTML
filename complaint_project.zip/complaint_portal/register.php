<?php
include 'db.php';

if (isset($_POST['register'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $pass = $_POST['password'];

    $q = "INSERT INTO students (name,email,password) VALUES ('$name','$email','$pass')";
    mysqli_query($con, $q);
    header("Location: login.php");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
<h3>Student Registration</h3>
<form method="post">
    <input type="text" name="name" class="form-control" placeholder="Name" required><br>
    <input type="email" name="email" class="form-control" placeholder="Email" required><br>
    <input type="password" name="password" class="form-control" placeholder="Password" required><br>
    <button name="register" class="btn btn-primary">Register</button>
</form>
</div>
</body>
</html>
